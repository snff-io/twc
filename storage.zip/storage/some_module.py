def hi():
    print("yo")

__all__ = ['hi']